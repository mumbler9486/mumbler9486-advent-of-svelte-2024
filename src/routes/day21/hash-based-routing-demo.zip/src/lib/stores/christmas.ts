import { writable } from 'svelte/store';

export const christmasStore = writable(0);
