<svelte:head>
	<title>About</title>
	<meta name="description" content="About this app" />
</svelte:head>

<div class="text-column">
	<h1>About this app</h1>

	<p>
		This is mean for the <a href="https://svelte.dev/blog/advent-of-svelte">Advent of Svelte 2024</a>. My solutions page is at <a href="https://mumbler9486-advent-of-svelte-2024.pages.dev/">https://mumbler9486-advent-of-svelte-2024.pages.dev/</a> 
	</p>

	<p>
		This website is mainly to demo the <strong>hash-based routing</strong> introduced into SvelteKit (21st day of the advent). Clicking on the navigation links will have the hash based routes. Note that in SvelteKit the routes for the pages are still directory based like normal but you will need to update all links to use the # in the URL for it to work. Also, if you need to know what the current url's pathname you should use the <code>page.route</code> state instead. 
	</p>
</div>
