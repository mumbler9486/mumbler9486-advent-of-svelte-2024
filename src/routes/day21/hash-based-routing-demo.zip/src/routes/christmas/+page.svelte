<script>
	import Counter from '../Counter.svelte';
	import { christmasStore } from '$lib/stores/christmas'

  const emoji = ['❄', '⛄', '🌨', '🎅', '🎄', '🎁', '🤶', '🧝‍♀️', '🧝‍♂️', '🦌'];
</script>

<p>Increase the christmas!</p>
<section>
	<Counter />
</section>

<div class="merry-zone">
{#each Array($christmasStore).fill(0)}
  {emoji[Math.floor(Math.random() * emoji.length)]}
{/each}
</div>

<style scoped>
  .merry-zone {
    font-size: 2rem;
  }
</style>